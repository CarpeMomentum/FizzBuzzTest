//: Interview Fizzbuzz Test

import UIKit

for i in 1...100 {
    let x = Double(i)
    let fizzRemainder = x.remainder(dividingBy: 3)
    let buzzRemainder = x.remainder(dividingBy: 5)
    
    //    if  fizzRemainder == 0 &&
    //        buzzRemainder == 0 {
    //        print("FizzBuzz  \(i)")
    //    }
    //    else if fizzRemainder == 0 {
    //        print("Fizz  \(i)")
    //    }
    //    else if buzzRemainder == 0 {
    //        print("Buzz  \(i)")
    //    }
    //    else {
    //        print(i)
    //    }
    // *** Challenge: Use switch instead of if/else statements....
    switch fizzRemainder {
        
    case let FizzBuzz where (fizzRemainder == 0) &&
        (buzzRemainder == 0):
        print("FizzBuzz  \(i)")
        
    case 0:
        print("Fizz  \(i)")
        
    case let Buzz where (buzzRemainder == 0):
        print("Buzz  \(i)")
        
    default:
        print(i)
    }
}
